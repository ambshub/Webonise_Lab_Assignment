insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (1,'Shubham','Shukla','ambshub@yahoo.co.in','test@123','1234567890');
insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (2,'Yogita','Bajpai','abcd@gmail.com','test@1','0987654321');

